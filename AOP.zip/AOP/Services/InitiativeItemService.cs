﻿using AOP.Entities;

namespace AOP.Services
{
    public class InitiativeItemService
    {
        public InitiativeItemService() { }
        RepositoryContext context;

        public void PostData(InitiativeItems entity)
        {
            context.Add(entity);    
            context.SaveChanges();
        }
        public List<InitiativeItems> GetData()
        {
            return new List<InitiativeItems>
            {
                new InitiativeItems
                {
                    IsActive = true,
                    Retail ="test"
                }
            };
        }

    }
}
