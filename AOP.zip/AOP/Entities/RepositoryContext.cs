﻿using Microsoft.EntityFrameworkCore;
using System.Security.Principal;

namespace AOP.Entities
{
    public class RepositoryContext : DbContext
    {
        public RepositoryContext(DbContextOptions options)
            : base(options)
        {
        }
        public DbSet<InitiativeItems>? InitiativeItems { get; set; }
       
    }
}
