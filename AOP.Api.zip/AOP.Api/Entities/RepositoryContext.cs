﻿using Microsoft.EntityFrameworkCore;

namespace AOP.Api.Entities
{
    public class RepositoryContext : DbContext
    {
        public RepositoryContext(DbContextOptions options)
            : base(options)
        {

        }


    }
}
